# Audit

Geprüft nach WCAG 2.2, Stufe A und AA, in Chrome.

## Übungsseite „Workshop: Formulare im Web“ (Datum)

| Kriterium | Stufe | Prüfung | Ergebnis | Maßnahme |
|---|---|---|---|---|
| 1.1.1 Non-text Content | A | Name des Bildes im Tab **Accessibility** | nicht erfüllt: Der Raumplan hat kein `alt`, sein Name ist leer. | `alt="Raumplan des zweiten Obergeschosses: Raum 2.14 liegt rechts oben, der Aufzug links unten am Flur"` |
| 1.3.1 Info and Relationships | A | Feld „E-Mail“ im Tab **Accessibility** | nicht erfüllt: Das Feld hat keinen Namen. „E-Mail“ ist ein Absatz, kein Label. | `<label for="email">E-Mail</label>` und `id="email"` am Feld |
| 1.4.1 Use of Color | A | **Emulate vision deficiencies: Deuteranopia** | nicht erfüllt: Freie und ausgebuchte Termine unterscheiden sich nur in der Farbe des Punkts. | Text „ausgebucht“ am Termin |
| 1.4.3 Contrast (Minimum) | AA | Kontrast im Tooltip des **Inspect mode** | nicht erfüllt: Hinweis zur Anmeldung `2.84` | Textfarbe `#666` (`5.74`) |
| 2.1.1 Keyboard | A | Seite nur mit `Tab`, `Enter` und Pfeiltasten bedienen | nicht erfüllt: Die Anfahrt erscheint nur unter dem Mauszeiger. Kein Tab-Stopp erreicht sie. | Anfahrt als Absatz auf der Seite |
| 2.4.7 Focus Visible | AA | Mit `Tab` durch die Seite | nicht erfüllt: Kein Tab-Stopp hat einen sichtbaren Fokus. | Regel `*:focus { outline: none; }` löschen |

## Toolbox (Datum)

| Kriterium | Stufe | Prüfung | Ergebnis | Maßnahme |
|---|---|---|---|---|
| 2.4.1 Bypass Blocks | A | Tab-Stopps bis zum ersten Link im Hauptinhalt zählen, 1280 px | nicht erfüllt: 30 Tab-Stopps | Skip-Link: erledigt |
| 1.4.11 Non-text Contrast | AA | Akzent probeweise als Textfarbe in der Sidebar, Kontrast im Color Picker | nicht erfüllt: Fokusrahmen `2.84` zur Sidebar | Fokusrahmen in `--color-accent-text`: erledigt, `5.68` |
