# Anforderungen an die Barrierefreiheit

Gilt für jede Seite der Toolbox. Maßstab ist die WCAG 2.2, Stufe AA. Jede Anforderung nennt ein Erfolgskriterium und eine Prüfung.

| Kriterium | Anforderung | Prüfung |
|---|---|---|
| 1.1.1 Non-text Content (A) | Jedes Bild mit Inhalt hat einen Alt-Text, der den Inhalt nennt. Ein Bild ohne Inhalt hat `alt=""`. | Im Tab **Accessibility** hat jedes Bild mit Inhalt einen Namen. |
| 1.3.1 Info and Relationships (A) | Jedes Feld hat ein Label. Überschriften, Listen und Tabellen sind mit den passenden Elementen ausgezeichnet. | Im Tab **Accessibility** hat jedes Feld einen Namen. |
| 1.4.1 Use of Color (A) | Farbe ist nie das einzige Merkmal einer Information. | Mit **Emulate vision deficiencies: Deuteranopia (no green)** ist jede Information erkennbar. |
| 1.4.3 Contrast (Minimum) (AA) | Text hat einen Kontrast von mindestens 4,5:1 zum Hintergrund. | Kontrast im Tooltip des **Inspect mode**, im Light Mode und im Dark Mode |
| 1.4.11 Non-text Contrast (AA) | Rahmen von Feldern und Buttons und der Fokusrahmen haben mindestens 3:1 zur angrenzenden Fläche. | Farbe probeweise als Textfarbe setzen und den Kontrast im Color Picker ablesen |
| 2.1.1 Keyboard (A) | Jede Funktion ist mit der Tastatur bedienbar. | Jede Seite ohne Maus bedienen |
| 2.4.1 Bypass Blocks (A) | Der erste Tab-Stopp ist ein Link zum Hauptinhalt. | Seite neu laden, `Tab`, `Enter`, `Tab`: Der Fokus steht auf dem ersten Link im Hauptinhalt. |
| 2.4.7 Focus Visible (AA) | Jedes Element mit Fokus hat einen sichtbaren Rahmen. | Mit `Tab` durch die Seite: Der Fokus ist auf jedem Tab-Stopp zu sehen. |
