# Toolbox

Bauteile für das Web: moderne HTML- und CSS-Patterns zum Nachschlagen – gebaut mit genau diesen Patterns.

## Ansehen

`index.html` im Browser öffnen (Doppelklick oder in den Browser ziehen). Die Seite braucht keinen Server und keine Installation.

## Struktur

```
toolbox/
├── README.md           ← diese Datei
├── learning-notizen.md ← Lernprotokoll: Vorhersagen und Beobachtungen
├── audit.md            ← Audit-Protokoll: Kriterium, Prüfung, Ergebnis, Maßnahme
├── anforderung.md      ← Anforderungen an die Barrierefreiheit, je mit Prüfung
├── .gitignore          ← Systemdateien, die nicht ins Repository gehören
├── index.html          ← Übersicht mit Links auf alle Einträge
├── ueber.html          ← Über dieses Projekt
├── patterns/           ← je Eintrag eine Seite
│   ├── html-grundgeruest.html
│   ├── landmarks.html
│   ├── ueberschriften.html
│   ├── listen.html
│   ├── links.html
│   ├── tabellen.html
│   ├── breadcrumbs.html
│   ├── aktuelle-seite.html
│   ├── bilder.html
│   ├── responsive-images.html
│   ├── label-fehlermeldung.html
│   ├── selektoren.html
│   ├── box-model.html
│   ├── cascade-layers.html
│   ├── custom-properties.html
│   ├── progressive-enhancement.html
│   ├── flexbox.html
│   ├── seitenlayout.html
│   ├── auto-fill-grid.html
│   ├── media-queries.html
│   ├── clamp.html
│   ├── container-queries.html
│   ├── design-tokens.html
│   ├── oklch.html
│   ├── light-dark.html
│   ├── akkordeon.html
│   ├── popover-menue.html
│   └── skip-link.html
└── assets/
    ├── css/
    │   ├── main.css       ← einzige eingebundene Datei: Reihenfolge der Ebenen, Importe
    │   ├── tokens.css     ← Tokens: Farben, Schriften, Schriftgrößen, Zeilenhöhen, Abstände
    │   ├── base.css       ← Schriften, Reset, HTML-Elemente ohne Klassen
    │   ├── layout.css     ← Seitenlayout: Grid Areas, Sidebar als Popover und ab 64rem, Flexbox im Header
    │   ├── components.css ← Komponenten mit einer Klasse: Code-Block, Pattern-Liste, Skip-Link
    │   └── overrides.css  ← eigene Gestaltung (freiwillig), gewinnt gegen alle anderen Dateien
    ├── fonts/          ← Schriften + Lizenzen (vorgegeben)
    └── img/            ← Bilder (vorgegeben, CC0 1.0)
```

Header, Sidebar und Footer stehen in jeder HTML-Datei. Eine Änderung an der Sidebar betrifft alle dreißig Seiten.

Jede Regel des Stylesheets steht in einer der fünf Ebenen `tokens`, `base`, `layout`, `components` und `overrides`. Eigene Gestaltung steht nur in `overrides.css`; dort legt `--accent-hue` die Akzentfarbe fest.

Das Stylesheet folgt Mobile-first: Die Regeln ohne Bedingung beschreiben die Seite mit einer Spalte. Unter 64rem öffnet der Button „Patterns“ die Sidebar als Popover. Ab dem Breakpoint 64rem steht die Sidebar in einer eigenen Spalte. Die Seite enthält kein JavaScript.

Farbwerte stehen nur in `tokens.css` und `overrides.css`, Schriftnamen außerdem in den Regeln `@font-face` von `base.css`. Jede Farbe ist ein Token mit zwei Werten in `light-dark()`: Die Seite folgt dem Color Scheme des Betriebssystems. Text hat in beiden Color Schemes einen Kontrast von mindestens 4,5:1 zum Hintergrund, der Fokusrahmen mindestens 3:1. Ein Browser ohne `light-dark()` erhält über `@supports` die Farben des Light Mode.

## Fortschritt

| Kapitel | Status |
|---|---|
| Das Skelett | erledigt |
| Text & Semantik | erledigt |
| Navigation & mehrere Seiten | erledigt |
| Bilder | erledigt |
| Tabellen & Formulare | erledigt |
| CSS-Grundlagen | erledigt |
| CSS-Fundament | erledigt |
| Layout | erledigt |
| Responsive | erledigt |
| Design-System | erledigt |
| Nicht jeder Browser kann alles | erledigt |
| Interaktion ohne JavaScript | erledigt |
| Barrierefreiheit prüfen | erledigt |

## Quellen

- [MDN Web Docs](https://developer.mozilla.org/) – Primärquelle für alle Einträge
