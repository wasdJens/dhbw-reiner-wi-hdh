# Toolbox

Bauteile für das Web: moderne HTML- und CSS-Patterns zum Nachschlagen – gebaut mit genau diesen Patterns.

## Ansehen

`index.html` im Browser öffnen (Doppelklick oder in den Browser ziehen). Die Seite braucht keinen Server und keine Installation.

## Struktur

```
toolbox/
├── README.md          ← diese Datei
├── learning-notizen.md ← Lernprotokoll: Vorhersagen und Beobachtungen
├── .gitignore         ← Systemdateien, die nicht ins Repository gehören
├── index.html         ← Startseite mit allen Einträgen
└── assets/
    ├── css/
    │   └── base.css   ← Start-Stylesheet (vorgegeben)
    └── fonts/         ← Schriften + Lizenzen (vorgegeben)
```

## Fortschritt

| Kapitel | Status |
|---|---|
| Das Skelett | erledigt |
| Text & Semantik | erledigt |
| Navigation & mehrere Seiten | offen |

## Quellen

- [MDN Web Docs](https://developer.mozilla.org/) – Primärquelle für alle Einträge
