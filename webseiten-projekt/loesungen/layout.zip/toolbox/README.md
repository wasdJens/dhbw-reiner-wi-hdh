# Toolbox

Bauteile für das Web: moderne HTML- und CSS-Patterns zum Nachschlagen – gebaut mit genau diesen Patterns.

## Ansehen

`index.html` im Browser öffnen (Doppelklick oder in den Browser ziehen). Die Seite braucht keinen Server und keine Installation.

## Struktur

```
toolbox/
├── README.md           ← diese Datei
├── learning-notizen.md ← Lernprotokoll: Vorhersagen und Beobachtungen
├── .gitignore          ← Systemdateien, die nicht ins Repository gehören
├── index.html          ← Übersicht mit Links auf alle Einträge
├── ueber.html          ← Über dieses Projekt
├── patterns/           ← je Eintrag eine Seite
│   ├── html-grundgeruest.html
│   ├── landmarks.html
│   ├── ueberschriften.html
│   ├── listen.html
│   ├── links.html
│   ├── tabellen.html
│   ├── breadcrumbs.html
│   ├── aktuelle-seite.html
│   ├── bilder.html
│   ├── responsive-images.html
│   ├── label-fehlermeldung.html
│   ├── selektoren.html
│   ├── box-model.html
│   ├── cascade-layers.html
│   ├── custom-properties.html
│   ├── flexbox.html
│   ├── seitenlayout.html
│   └── auto-fill-grid.html
└── assets/
    ├── css/
    │   ├── main.css       ← einzige eingebundene Datei: Reihenfolge der Ebenen, Importe
    │   ├── tokens.css     ← Custom Properties: Farben, Schriften, Abstände
    │   ├── base.css       ← Schriften, Reset, HTML-Elemente ohne Klassen
    │   ├── layout.css     ← Seitenlayout: Grid mit drei Grid Areas, Flexbox im Header
    │   ├── components.css ← Komponenten mit einer Klasse: Code-Block, Pattern-Liste
    │   └── overrides.css  ← eigene Gestaltung (freiwillig), gewinnt gegen alle anderen Dateien
    ├── fonts/          ← Schriften + Lizenzen (vorgegeben)
    └── img/            ← Bilder (vorgegeben, CC0 1.0)
```

Header, Navigation und Footer stehen in jeder HTML-Datei. Eine Änderung an der Navigation betrifft alle zwanzig Seiten.

Jede Regel des Stylesheets steht in einer der fünf Ebenen `tokens`, `base`, `layout`, `components` und `overrides`. Eigene Gestaltung steht nur in `overrides.css`; dort legt `--accent-hue` die Akzentfarbe fest.

## Fortschritt

| Kapitel | Status |
|---|---|
| Das Skelett | erledigt |
| Text & Semantik | erledigt |
| Navigation & mehrere Seiten | erledigt |
| Bilder | erledigt |
| Tabellen & Formulare | erledigt |
| CSS-Grundlagen | erledigt |
| CSS-Fundament | erledigt |
| Layout | erledigt |
| Responsive | offen |

## Quellen

- [MDN Web Docs](https://developer.mozilla.org/) – Primärquelle für alle Einträge
