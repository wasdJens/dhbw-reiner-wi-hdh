# Toolbox

Bauteile für das Web: moderne HTML- und CSS-Patterns zum Nachschlagen – gebaut mit genau diesen Patterns.

## Ansehen

`index.html` im Browser öffnen (Doppelklick oder in den Browser ziehen). Die Seite braucht keinen Server und keine Installation.

## Struktur

```
toolbox/
├── README.md           ← diese Datei
├── learning-notizen.md ← Lernprotokoll: Vorhersagen und Beobachtungen
├── .gitignore          ← Systemdateien, die nicht ins Repository gehören
├── index.html          ← Übersicht mit Links auf alle Einträge
├── ueber.html          ← Über dieses Projekt
├── patterns/           ← je Eintrag eine Seite
│   ├── html-grundgeruest.html
│   ├── landmarks.html
│   ├── ueberschriften.html
│   ├── listen.html
│   ├── links.html
│   ├── breadcrumbs.html
│   └── aktuelle-seite.html
└── assets/
    ├── css/
    │   └── base.css    ← Start-Stylesheet 2.1.0 (vorgegeben)
    └── fonts/          ← Schriften + Lizenzen (vorgegeben)
```

Header, Navigation und Footer stehen in jeder HTML-Datei. Eine Änderung an der Navigation betrifft alle neun Seiten.

## Fortschritt

| Kapitel | Status |
|---|---|
| Das Skelett | erledigt |
| Text & Semantik | erledigt |
| Navigation & mehrere Seiten | erledigt |
| Bilder | offen |

## Quellen

- [MDN Web Docs](https://developer.mozilla.org/) – Primärquelle für alle Einträge
